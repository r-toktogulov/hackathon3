export const API = "http://localhost:8000/products";
export const newAPI = "http://localhost:8000/users";
