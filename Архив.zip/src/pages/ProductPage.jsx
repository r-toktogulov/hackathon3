import React from "react";

const ProductPage = () => {
  console.log("heeloo");
  return (
    <div>
      <h1>Product Page</h1>
    </div>
  );
};

export default ProductPage;
